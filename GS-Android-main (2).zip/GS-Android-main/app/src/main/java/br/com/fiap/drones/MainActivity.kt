package br.com.fiap.drones

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import br.com.fiap.drones.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        supportActionBar!!.hide()
        window.statusBarColor = Color.parseColor("#FFFFFF")

        binding.buttonLogin.setOnClickListener{
            val user = binding.editTextUser.text.toString()
            val email = binding.editTextEmail.text.toString()
            val senha = binding.editTextSenha.text.toString()

            when{
                email.isEmpty() -> {
                    binding.editTextEmail.error = "Preencha essa merda de E-mail ai!!"
                }
                senha.isEmpty() -> {
                    binding.editTextSenha.error = "Digite sua senha!"
                }
                !email.contains("@gmail.com") ->{
                 val snackbar = Snackbar.make(it, "E-mail inválido", Snackbar.LENGTH_SHORT)
                    snackbar.show()
                }
                senha.length <= 5 ->{
                    val snackbar = Snackbar.make(it, "Senha precisa ter pelo menos 6 caracteres!", Snackbar.LENGTH_SHORT)
                    snackbar.show()
                }
                else ->{
                  binding.buttonLogin.isEnabled = false
                    binding.buttonLogin.setTextColor(Color.parseColor("#FFFFFF"))
                    sucesso()

                }
            }
        }
    }

    private fun sucesso(){
        val intent = Intent(this, HomePage::class.java)
        startActivity(intent)
    }

}